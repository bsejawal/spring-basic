package com.sejawal.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sejawal.constant.ClientURL;
import com.sejawal.model.dto.AggregatorResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UsingCompletableFutureTest {

    @Mock
    private HttpClient client;

    private UsingCompletableFuture service;

    @BeforeEach
    void setUp() {
        ObjectMapper mapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        service = new UsingCompletableFuture(mapper, client);
    }

    @Test
    void aggregatesResponsesIntoWrapper() {
        when(client.sendAsync(any(HttpRequest.class), any(HttpResponse.BodyHandler.class)))
                .thenAnswer(invocation -> {
                    HttpRequest request = invocation.getArgument(0);
                    String body = bodyFor(request.uri());

                    HttpResponse<String> response = org.mockito.Mockito.mock(HttpResponse.class);
                    when(response.statusCode()).thenReturn(200);
                    when(response.body()).thenReturn(body);
                    return CompletableFuture.completedFuture(response);
                });

        AggregatorResponse response = service.getRestAPIConsumeAsync().join();

        assertThat(response).isNotNull();
        assertThat(response.getListPost().getPosts()).hasSize(1);
        assertThat(response.getListPost().getPosts().get(0).getId()).isEqualTo(1);
        assertThat(response.getPpage().getResults()).hasSize(1);
        assertThat(response.getEarthquake().getType()).isEqualTo("FeatureCollection");
    }

    private static String bodyFor(URI uri) {
        String url = uri.toString();
        if (ClientURL.jsonPlaceholderUrl.equals(url)) {
            return "[{\"userId\":1,\"id\":1,\"title\":\"t\",\"body\":\"b\"}]";
        }
        if (ClientURL.pokemonUrl.equals(url)) {
            return "{\"count\":1,\"next\":null,\"previous\":null," +
                    "\"results\":[{\"name\":\"bulbasaur\",\"url\":\"https://pokeapi.co/api/v2/pokemon/1/\"}]}";
        }
        if (ClientURL.earthquakeUrl.equals(url)) {
            return "{\"type\":\"FeatureCollection\",\"features\":[]," +
                    "\"bbox\":[0.0,0.0,0.0,0.0,0.0,0.0]}";
        }
        throw new IllegalArgumentException("Unexpected URL: " + url);
    }
}
