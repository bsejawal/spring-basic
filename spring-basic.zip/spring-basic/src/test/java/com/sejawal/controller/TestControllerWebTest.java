//package com.sejawal.controller;
//
//import com.sejawal.model.jsonplaceholder.ListPost;
//import com.sejawal.model.jsonplaceholder.Post;
//import com.sejawal.service.UsingHttpClientService;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.web.servlet.MockMvc;
//
//import java.util.List;
//
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//@WebMvcTest(TestController.class)
//class TestControllerWebTest {
//
//    @Autowired
//    private MockMvc mockMvc;
//
//    @MockBean
//    private UsingHttpClientService httpClientService;
//
//    @Test
//    void returnsListPostWrapper() throws Exception {
//        ListPost payload = new ListPost(List.of(new Post(1, 1, "title", "body")));
//        when(httpClientService.getRestAPIConsume()).thenReturn(payload);
//
//        mockMvc.perform(get("/test"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.posts").isArray())
//                .andExpect(jsonPath("$.posts[0].id").value(1))
//                .andExpect(jsonPath("$.posts[0].title").value("title"));
//    }
//}
