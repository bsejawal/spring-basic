package com.sejawal.constant;

import java.time.Duration;

public class ClientURL {
    public static final Duration TIMEOUT = Duration.ofMillis(900);
    public static final String DEFAULT_USER_AGENT = "spring-basic(bsejawal@gmail.com)";
    public static final String ACCEPT = "application/json";
    public static final String jsonPlaceholderUrl = "https://jsonplaceholder.typicode.com/posts";
    public static final String pokemonUrl = "https://pokeapi.co/api/v2/pokemon?offset=0&limit=20";
    public static final String earthquakeUrl = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson";
}
