package com.sejawal.controller;

import com.sejawal.model.dto.AggregatorResponse;
import com.sejawal.service.UsingCompletableFuture;
import com.sejawal.service.UsingHttpClientService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class TestController {
    private final UsingHttpClientService httpClientService;
    private final UsingCompletableFuture usingCompletableFuture;

    @GetMapping("/blocking")
    public ResponseEntity<AggregatorResponse> t(){
        long startTime = System.currentTimeMillis();
        AggregatorResponse response = httpClientService.getRestAPIConsume();
        long endTime = System.currentTimeMillis();
        System.out.println("getRestAPIConsume Time taken: " + (endTime - startTime));
        return new ResponseEntity(response, HttpStatus.OK);
    }

    @GetMapping("/async")
    public ResponseEntity<AggregatorResponse> tt(){
        long startTime = System.currentTimeMillis();
        AggregatorResponse response = usingCompletableFuture.getRestAPIConsumeAsync().join();
        long endTime = System.currentTimeMillis();
        System.out.println("getRestAPIConsumeAsync Time taken: " + (endTime - startTime));
        return new ResponseEntity(response, HttpStatus.OK);
    }

    @GetMapping("/test")
    public ResponseEntity<String> test(){

        long startTime = System.currentTimeMillis();
        AggregatorResponse response = httpClientService.getRestAPIConsume();
        long endTime = System.currentTimeMillis();
        System.out.println("getRestAPIConsume Time taken: " + (endTime - startTime));

        long startTimeAsync = System.currentTimeMillis();
        AggregatorResponse response1 = usingCompletableFuture.getRestAPIConsumeAsync().join();
        long endTimeAsync = System.currentTimeMillis();
        System.out.println("getRestAPIConsumeAsync Time taken: " + (endTimeAsync - startTimeAsync));
        return new ResponseEntity("OK", HttpStatus.OK);
    }
}
