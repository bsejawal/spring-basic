package com.sejawal.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sejawal.constant.ClientURL;
import com.sejawal.model.dto.AggregatorResponse;
import com.sejawal.model.earchquake.Earthquake;
import com.sejawal.model.jsonplaceholder.ListPost;
import com.sejawal.model.jsonplaceholder.Post;
import com.sejawal.model.pokemon.PPage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RequiredArgsConstructor
@Service
public class UsingCompletableFuture {

    private final ObjectMapper mapper;
    private final HttpClient client;

    public CompletableFuture<AggregatorResponse> getRestAPIConsumeAsync() {
        Map<String, String> jsonHeaders = headers(
                "User-Agent", ClientURL.DEFAULT_USER_AGENT,
                "Accept", ClientURL.ACCEPT
        );

        CompletableFuture<ListPost> postsFuture = getJsonAsync(
                ClientURL.jsonPlaceholderUrl,
                new TypeReference<List<Post>>() {
                },
                jsonHeaders
        ).thenApply(ListPost::new);

        CompletableFuture<PPage> pokemonFuture = getJsonAsync(
                ClientURL.pokemonUrl,
                PPage.class,
                jsonHeaders
        );

        CompletableFuture<Earthquake> earthquakeFuture = getJsonAsync(
                ClientURL.earthquakeUrl,
                Earthquake.class,
                headers(
                        "User-Agent", ClientURL.DEFAULT_USER_AGENT,
                        "Accept", "application/geo+json"
                )
        );

        return CompletableFuture.allOf(postsFuture, pokemonFuture, earthquakeFuture)
                .thenApply(ignored -> new AggregatorResponse(
                        postsFuture.join(),
                        pokemonFuture.join(),
                        earthquakeFuture.join()
                ));
    }

    private static Map<String, String> headers(String... kv) {
        if (kv.length % 2 != 0) {
            throw new IllegalArgumentException("headers() requires even number of strings: key,value,key,value...");
        }
        Map<String, String> map = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            map.put(kv[i], kv[i + 1]);
        }
        return map;
    }

    private <T> CompletableFuture<T> getJsonAsync(String url, TypeReference<T> typeRef, Map<String, String> headers) {
        return getBodyAsync(url, headers)
                .thenApply(body -> {
                    try {
                        return mapper.readValue(body, typeRef);
                    } catch (IOException e) {
                        throw new RuntimeException("Failed to parse JSON from " + url, e);
                    }
                });
    }

    private <T> CompletableFuture<T> getJsonAsync(String url, Class<T> clazz, Map<String, String> headers) {
        return getBodyAsync(url, headers)
                .thenApply(body -> {
                    try {
                        return mapper.readValue(body, clazz);
                    } catch (IOException e) {
                        throw new RuntimeException("Failed to parse JSON from " + url, e);
                    }
                });
    }

    private CompletableFuture<String> getBodyAsync(String url, Map<String, String> headers) {
        HttpRequest request = buildGetRequest(url, headers);
        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    int code = response.statusCode();
                    if (code < 200 || code >= 300) {
                        throw new RuntimeException("HTTP " + code + " from " + url);
                    }
                    return response.body();
                });
    }

    private HttpRequest buildGetRequest(String url, Map<String, String> headers) {
        HttpRequest.Builder b = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(ClientURL.TIMEOUT)
                .GET();

        if (headers != null) {
            headers.forEach((k, v) -> {
                if (k != null && v != null) b.header(k, v);
            });
        }
        return b.build();
    }
}
