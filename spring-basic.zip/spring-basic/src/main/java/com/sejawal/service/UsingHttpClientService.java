package com.sejawal.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sejawal.constant.ClientURL;
import com.sejawal.model.dto.AggregatorResponse;
import com.sejawal.model.earchquake.Earthquake;
import com.sejawal.model.jsonplaceholder.ListPost;
import com.sejawal.model.pokemon.PPage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
@Service
public class UsingHttpClientService {


    private final ObjectMapper mapper;
    private final HttpClient client;

    public AggregatorResponse getRestAPIConsume() {
        // jsonplaceholder (note: TypeReference<> inference should work like your current code)
        ListPost posts = new ListPost(
                getJson(ClientURL.jsonPlaceholderUrl, new TypeReference<>() {
                }, headers("User-Agent", ClientURL.DEFAULT_USER_AGENT))
        );

        // pokemon
        PPage ppage = getJson(ClientURL.pokemonUrl, PPage.class, headers("User-Agent", ClientURL.DEFAULT_USER_AGENT));

        // earthquake (custom headers)
        Earthquake earthquake = getJson(
                ClientURL.earthquakeUrl,
                Earthquake.class,
                headers(
                        "User-Agent", "spring-basic/1.0 (bsejawal@gmail.com)",
                        "Accept", "application/geo+json"
                )
        );
        return new AggregatorResponse(posts, ppage, earthquake);
    }

    private static Map<String, String> headers(String... kv) {
        if (kv.length % 2 != 0) {
            throw new IllegalArgumentException("headers() requires even number of strings: key,value,key,value...");
        }
        Map<String, String> map = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            map.put(kv[i], kv[i + 1]);
        }
        return map;
    }

    private static String safeSnippet(String body, int maxLen) {
        if (body == null) return "";
        return body.length() <= maxLen ? body : body.substring(0, maxLen) + "...";
    }

    private <T> T getJson(String url, TypeReference<T> typeRef, Map<String, String> headers){
        String body = getBody(url, headers);
        try{
            return mapper.readValue(body, typeRef);
        }catch (IOException e){
            throw new RuntimeException("Failed to parse JSON from " + url, e);
        }
    }

    private <T> T getJson(String url, Class<T> clazz, Map<String, String> headers){
        String body = getBody(url, headers);
        try{
            return mapper.readValue(body, clazz);
        }catch (IOException e){
            throw new RuntimeException("Failed to parse JSON from " + url, e);
        }
    }

    private String getBody(String url, Map<String, String> headers) {
        HttpRequest request = buildGetRequest(url, headers);
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            int code = response.statusCode();
            if (code < 200 || code >= 300) {
//                String snippet = safeSnippet(response.body(), 600);
                throw new RuntimeException("HTTP " + code + " from " + url);
            }
            return response.body();

        } catch (IOException e) {
            throw new RuntimeException("I/O error calling " + url, e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted calling " + url, e);
        }
    }

    private HttpRequest buildGetRequest(String url, Map<String, String> headers) {
        HttpRequest.Builder b = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(ClientURL.TIMEOUT)
                .GET();

        if (headers != null) {
            headers.forEach((k, v) -> {
                if (k != null && v != null) b.header(k, v);
            });
        }
        return b.build();
    }

}
