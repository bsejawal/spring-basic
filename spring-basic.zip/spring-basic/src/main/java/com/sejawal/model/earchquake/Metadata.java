package com.sejawal.model.earchquake;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Metadata {

    private long generated;
    private String url;
    private String title;
    private int status;
    private String api;
    private int limit;
    private int offset;
    private int count;
}
