package com.sejawal.model.earchquake;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeatureProperties {

    private Double mag;
    private String place;

    private long time;
    private long updated;

    private Integer tz;

    private String url;
    private String detail;

    private Integer felt;
    private Double cdi;
    private Double mmi;

    private String alert;
    private String status;

    private Integer tsunami;
    private Integer sig;

    private String net;
    private String code;

    private String ids;
    private String sources;
    private String types;

    private Integer nst;
    private Double dmin;
    private Double rms;

    private Integer gap;
    private String magType;

    @JsonProperty("type")
    private String eventType;        // e.g. "earthquake"

    private String title;
}
