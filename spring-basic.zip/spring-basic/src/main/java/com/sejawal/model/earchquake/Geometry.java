package com.sejawal.model.earchquake;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Geometry {
    private String type;                 // "Point"
    private List<Double> coordinates;    // [longitude, latitude, depthKm]
}
