package com.sejawal.model.pokemon;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PPage {

    private int count;
    private String next;
    private String previous;
    private List<PResult> results;
}
