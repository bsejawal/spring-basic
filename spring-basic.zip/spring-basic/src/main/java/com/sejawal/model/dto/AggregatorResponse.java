package com.sejawal.model.dto;

import com.sejawal.model.earchquake.Earthquake;
import com.sejawal.model.jsonplaceholder.ListPost;
import com.sejawal.model.pokemon.PPage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AggregatorResponse {
    private ListPost listPost;
    private PPage ppage;
    private Earthquake earthquake;
}
