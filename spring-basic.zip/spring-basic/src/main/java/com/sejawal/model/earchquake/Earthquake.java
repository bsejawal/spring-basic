package com.sejawal.model.earchquake;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Earthquake {

    private String type;                 // "FeatureCollection"
    private Metadata metadata;           // metadata object
    private List<Feature> features;      // list of features
    private List<Double> bbox;           // [minLon, minLat, minDepth, maxLon, maxLat, maxDepth]
}
